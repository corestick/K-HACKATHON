package mobi.intuitit.android.mate.launcher;

import android.content.Context;
import android.util.AttributeSet;

public class MFolder extends UserFolderInfo {
	

	public MFolder() {
		itemType = LauncherSettings.Favorites.ITEM_TYPE_USER_FOLDER;
	}
	

}
