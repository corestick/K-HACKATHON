package mobi.intuitit.android.widget;

/**
 * 
 * @author Koxx
 * 
 */
public interface WidgetDataChangeListener {

	public void onChange();
}
